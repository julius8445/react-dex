import React from 'react';

function App(): JSX.Element {
    return (
        <div className="font-nunito text-5xl">
            <NavBar />
        </div>

    );
}



function NavBar(): JSX.Element {
    return (
        <div className="">
            cat
        </div>
    );
}

export default App;