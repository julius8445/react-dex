module.exports = {
    content: ["./src/*.{html,js,ts,jsx,tsx}"],
    theme: {
      fontFamily: {
        'nunito': ['nunito', 'sans-serif']
      },
      extend: {},
    },
    variants: {},
    plugins: [],
};

